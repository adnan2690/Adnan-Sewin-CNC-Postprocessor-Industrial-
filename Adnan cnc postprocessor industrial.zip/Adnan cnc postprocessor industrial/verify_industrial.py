import os
import sys

REQUIRED_FILES = [
    "Quantum_Core_Engine/Geometry_Processing/industrial_offset_generator.py",
    "Military_Grade_UI/Visualization_System/gpu_accelerated_canvas.py",
    "Industrial_Export_System/DXF_R12_Exporter/iso_compliant_dxf_writer.py",
    "Mach3_Macro_Suite/Macro_Files/M100_start_stitching.m1s",
    "Application_Entry/quantum_unified_loader.py"
]

def verify_installation():
    missing = []
    for file in REQUIRED_FILES:
        if not os.path.exists(file):
            missing.append(file)
    
    if missing:
        print("Industrial system incomplete! Missing files:")
        for file in missing:
            print(f" - {file}")
        sys.exit(1)
    
    print("Industrial CNC System Verified - All critical components present")
    print("System ready for global deployment!")

if __name__ == "__main__":
    verify_installation()